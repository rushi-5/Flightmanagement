import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcomeuser',
  templateUrl: './welcomeuser.component.html',
  styleUrls: ['./welcomeuser.component.css']
})
export class WelcomeuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
